# Rooibos sample test project.

Clone this project so you can start playing with rooibos 4 right now. It demonstrates:

 - project setup with the brighterscript compiler
   - folder structure
   - launch tasks
   - npm scripts
   - plugins
 - integration with roobios
   - installation
   - bsconfig configuration
   - custom test suite
 - basic test usage
   - beforeEach
   - beforeEach for a specific group
   - mocking



